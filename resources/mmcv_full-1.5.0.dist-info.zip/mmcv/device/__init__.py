# Copyright (c) OpenMMLab. All rights reserved.
from . import ipu, mlu

__all__ = ['mlu', 'ipu']
